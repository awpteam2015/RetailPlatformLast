The keygen requires .net framework 4.5
please donate to improve more cracks !
Regards !